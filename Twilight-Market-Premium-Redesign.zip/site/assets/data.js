window.TWILIGHT_PRODUCTS = {
  "foldable-turbo-fan": {
    "name": "Twilight Rechargeable Turbo Fan",
    "shortName": "Rechargeable Turbo Fan",
    "category": "Gadgets & Electronics",
    "price": 600,
    "unitLabel": "per piece",
    "freeDelivery": true,
    "delivery": "Free home delivery anywhere in Bangladesh.",
    "badge": "PORTABLE COOLING",
    "summary": "A compact rechargeable fan with five wind speeds, a digital display and a foldable body.",
    "description": "Stay comfortable at home, at work or while travelling. This compact turbo fan combines strong airflow with an ultra-quiet brushless motor, a clear digital display and a foldable design that works in your hand or on a table.",
    "images": [
      "turbo-fan.webp"
    ],
    "features": [
      "5 adjustable wind-speed modes",
      "3600mAh rechargeable battery",
      "Digital speed and battery display",
      "Foldable handheld and tabletop design",
      "Brushless motor for strong, quiet airflow",
      "Lightweight and easy to carry"
    ],
    "specs": [
      [
        "Price",
        "৳600"
      ],
      [
        "Delivery",
        "Free home delivery across Bangladesh"
      ],
      [
        "Battery",
        "3600mAh rechargeable"
      ],
      [
        "Speed modes",
        "5"
      ],
      [
        "Display",
        "Digital"
      ],
      [
        "Available colors",
        "Mint Green and White"
      ]
    ],
    "variants": [
      {
        "name": "Color",
        "options": [
          "Mint Green",
          "White"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 330
  },
  "kids-raincoat": {
    "name": "Twilight Kids EVA Raincoat",
    "shortName": "Kids EVA Raincoat",
    "category": "Rain Essentials",
    "price": 400,
    "unitLabel": "per piece",
    "freeDelivery": true,
    "delivery": "Free home delivery anywhere in Bangladesh.",
    "badge": "RAIN ESSENTIAL",
    "summary": "A soft, lightweight and reusable EVA raincoat made for school days, travel and sudden rain.",
    "description": "Keep children comfortably covered on rainy days with a soft EVA raincoat that is easy to fold, carry and reuse. The hooded, button-front design gives practical coverage without feeling heavy.",
    "images": [
      "kids-raincoat-400.webp"
    ],
    "features": [
      "Soft and comfortable EVA material",
      "Lightweight, foldable and portable",
      "Hooded button-front design",
      "Reusable waterproof protection",
      "Useful for school and family travel",
      "Standard and small packaging available"
    ],
    "specs": [
      [
        "Price",
        "৳400"
      ],
      [
        "Delivery",
        "Free home delivery across Bangladesh"
      ],
      [
        "Material",
        "EVA"
      ],
      [
        "Suggested height",
        "90–145 cm"
      ],
      [
        "Suggested weight",
        "30–70 kg"
      ],
      [
        "Packaging",
        "Standard Pack or Small Pack"
      ]
    ],
    "variants": [
      {
        "name": "Color",
        "options": [
          "Light Blue",
          "Rose Pink",
          "Black Tea",
          "Black",
          "Yellow",
          "Blue",
          "Gray",
          "White"
        ]
      },
      {
        "name": "Pack",
        "options": [
          "Standard Pack",
          "Small Pack"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 300
  },
  "adult-eva-raincoat": {
    "name": "Twilight Adult EVA Raincoat",
    "shortName": "Adult EVA Raincoat",
    "category": "Rain Essentials",
    "price": 450,
    "unitLabel": "per piece",
    "freeDelivery": true,
    "delivery": "Free home delivery anywhere in Bangladesh.",
    "badge": "RAIN ESSENTIAL",
    "summary": "A lightweight hooded adult raincoat with long coverage and a comfortable unisex fit.",
    "description": "A practical reusable raincoat for commuting, shopping and everyday travel. The long hooded design helps protect your clothes from rain while the lightweight EVA material folds easily into a bag when the weather clears.",
    "images": [
      "adult-raincoat.webp"
    ],
    "features": [
      "Adult unisex design",
      "Lightweight EVA rain protection",
      "Attached hood with drawstring",
      "Long button-front coverage",
      "Foldable and easy to carry",
      "Reusable for regular rainy-day use"
    ],
    "specs": [
      [
        "Price",
        "৳450"
      ],
      [
        "Delivery",
        "Free home delivery across Bangladesh"
      ],
      [
        "Material",
        "EVA"
      ],
      [
        "Fit",
        "Adult / Unisex"
      ],
      [
        "Closure",
        "Button front"
      ],
      [
        "Available colors",
        "Blue and Transparent White"
      ]
    ],
    "variants": [
      {
        "name": "Color",
        "options": [
          "Blue",
          "Transparent White"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 300
  },
  "transparent-floral-umbrella": {
    "name": "Twilight Transparent Floral Umbrella",
    "shortName": "Transparent Floral Umbrella",
    "category": "Rain Essentials",
    "price": 650,
    "unitLabel": "per piece",
    "freeDelivery": true,
    "delivery": "Free home delivery anywhere in Bangladesh.",
    "badge": "COMPACT DESIGN",
    "summary": "A transparent cherry-blossom umbrella with a compact matching bottle-style case.",
    "description": "Bring a cheerful look to rainy days with a transparent floral umbrella that is easy to fold and carry. Each color has a matching edge, handle and compact bottle-style storage case.",
    "images": [
      "umbrella-mint.webp",
      "umbrella-blue.webp",
      "umbrella-purple.webp",
      "umbrella-pink.webp",
      "umbrella-pink-outdoor.webp",
      "umbrella-cherry.webp"
    ],
    "features": [
      "Transparent cherry-blossom canopy",
      "Compact foldable design",
      "Matching bottle-style storage case",
      "Easy to keep in a bag or at work",
      "Four attractive color choices",
      "Suitable for daily rain protection"
    ],
    "specs": [
      [
        "Price",
        "৳650"
      ],
      [
        "Delivery",
        "Free home delivery across Bangladesh"
      ],
      [
        "Design",
        "Transparent floral"
      ],
      [
        "Type",
        "Compact folding umbrella"
      ],
      [
        "Storage",
        "Matching bottle case"
      ],
      [
        "Available colors",
        "Mint, Sky Blue, Purple and Pink"
      ]
    ],
    "variants": [
      {
        "name": "Color",
        "options": [
          "Mint Green",
          "Sky Blue",
          "Purple",
          "Pink"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 300
  },
  "raincoat-turbo-fan-combo": {
    "name": "Adult Raincoat + Turbo Fan Smart Combo",
    "shortName": "Smart Weather Combo",
    "category": "Combo Offer",
    "price": 999,
    "unitLabel": "per set",
    "freeDelivery": true,
    "delivery": "Free home delivery anywhere in Bangladesh.",
    "badge": "SEASONAL SET",
    "summary": "One adult EVA raincoat plus one rechargeable turbo fan in a practical all-weather value set.",
    "description": "Be ready for both rain and heat with two useful everyday products in one set. Choose the adult raincoat and turbo-fan colors separately before sending your complete order through WhatsApp.",
    "images": [
      "raincoat-fan-combo.webp",
      "turbo-fan.webp",
      "adult-raincoat.webp"
    ],
    "features": [
      "1 adult EVA raincoat",
      "1 rechargeable 5-speed turbo fan",
      "Separate raincoat and fan color choices",
      "Practical for commuting and travel",
      "Ready for rainy and hot weather",
      "Free home delivery across Bangladesh"
    ],
    "specs": [
      [
        "Combo price",
        "৳999"
      ],
      [
        "Delivery",
        "Free home delivery across Bangladesh"
      ],
      [
        "Raincoat",
        "Adult EVA raincoat"
      ],
      [
        "Fan",
        "3600mAh, 5 speed modes"
      ],
      [
        "Quantity",
        "1 raincoat + 1 fan"
      ],
      [
        "Ordering",
        "Select both colors before checkout"
      ]
    ],
    "variants": [
      {
        "name": "Raincoat Color",
        "options": [
          "Blue",
          "Transparent White"
        ]
      },
      {
        "name": "Fan Color",
        "options": [
          "Mint Green",
          "White"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 630
  },
  "premium-towel-gift-set": {
    "name": "Premium Coral Fleece Towel Gift Set",
    "shortName": "Towel Gift Set",
    "category": "Home & Lifestyle",
    "price": 999,
    "unitLabel": "per set",
    "freeDelivery": true,
    "delivery": "Free home delivery anywhere in Bangladesh.",
    "badge": "GIFT-READY SET",
    "summary": "One large bath towel and two face towels arranged in premium gift packaging.",
    "description": "A soft and highly absorbent three-piece coral fleece towel set presented in a premium gift box. It is suitable for daily family use and makes a thoughtful wedding, birthday or corporate gift.",
    "images": [
      "towel-set.webp"
    ],
    "features": [
      "1 large bath towel",
      "2 matching face towels",
      "Soft coral fleece fabric",
      "Fast and effective water absorption",
      "Premium gift-box presentation",
      "Suitable for home use and gifting"
    ],
    "specs": [
      [
        "Set price",
        "৳999"
      ],
      [
        "Delivery",
        "Free home delivery across Bangladesh"
      ],
      [
        "Set contents",
        "1 bath towel + 2 face towels"
      ],
      [
        "Material",
        "Coral fleece"
      ],
      [
        "Packaging",
        "Premium gift box"
      ],
      [
        "Available colors",
        "Pink, Green, Blue, Orange and Grass Green"
      ]
    ],
    "variants": [
      {
        "name": "Color",
        "options": [
          "Pink",
          "Green",
          "Blue",
          "Orange",
          "Grass Green"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 990
  },
  "travel-tea-set": {
    "name": "Twilight Ceramic Kung Fu Travel Tea Set",
    "shortName": "Travel Tea Set",
    "category": "Home & Lifestyle",
    "price": 1899,
    "unitLabel": "per set",
    "delivery": "Shipping from ৳80 inside Dhaka or ৳110 outside Dhaka; add ৳25 for each additional kg.",
    "badge": "COMPLETE SET",
    "summary": "A complete ceramic tea set with four cups, tray, cloth, tongs and a protective carrying case.",
    "description": "Enjoy a proper tea experience at home, at the office or while travelling. The ceramic teaware and accessories fit securely inside a compact protective case, making the set easy to carry and gift-ready.",
    "images": [
      "tea-set-open.webp",
      "tea-set-steps.webp",
      "tea-set-green.webp"
    ],
    "features": [
      "1 ceramic teapot and 4 cups",
      "Bamboo-style serving tray",
      "Tea cloth and tea tongs included",
      "Protective fitted travel case",
      "Compact organized storage",
      "Suitable for personal use or gifting"
    ],
    "specs": [
      [
        "Set price",
        "৳1,899"
      ],
      [
        "Delivery",
        "Inside Dhaka ৳80; outside Dhaka ৳110; +৳25 per additional kg"
      ],
      [
        "Teaware",
        "1 teapot + 4 cups"
      ],
      [
        "Accessories",
        "Tray, cloth and tongs"
      ],
      [
        "Case",
        "Protective carrying case"
      ],
      [
        "Available colors",
        "Off-white, Black and Light Green"
      ]
    ],
    "variants": [
      {
        "name": "Color",
        "options": [
          "Off-white",
          "Black",
          "Light Green"
        ]
      }
    ],
    "originalPrice": null,
    "weightGrams": 990
  }
};
